# Working with Text
## Work in Progress

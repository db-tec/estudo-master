structure(list(name = "mean", objs = structure(list(`package:base` = function (x, 
    ...) 
UseMethod("mean"), function (x, ...) 
UseMethod("mean")), .Names = c("package:base", "")), where = c("package:base", 
"namespace:base"), visible = c(TRUE, FALSE), dups = c(FALSE, 
TRUE)), .Names = c("name", "objs", "where", "visible", "dups"
), class = "getAnywhere")

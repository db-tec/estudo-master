# library(knitractive)
#
# engine <- ActiveEngine$new(
#   name = "bash",
#   shell_command = "docker run --rm -it datascienceworkshops/data-science-at-the-command-line:latest",
#   prompt = "^(\\[.*\\]\\$|>)$",
#   lexer = "shell-session"
# )
# engine$start()

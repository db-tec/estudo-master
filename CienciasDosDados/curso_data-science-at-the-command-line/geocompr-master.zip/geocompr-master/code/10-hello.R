# Aim: provide a minimal R script
print("Hello geocompr")
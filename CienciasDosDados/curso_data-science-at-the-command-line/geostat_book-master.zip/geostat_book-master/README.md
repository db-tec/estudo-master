# Geostatystyka w R

[![Build Status](https://travis-ci.org/Nowosad/geostat_book.svg?branch=master)](https://travis-ci.org/Nowosad/geostat_book)

Repozytorium zawierające kod źródłowy do skryptu akademickiego "Geostatystyka w R".
Wersję online tego skryptu można znaleźć pod adresem https://bookdown.org/nowosad/Geostatystyka/.

<a href="https://bookdown.org/nowosad/Geostatystyka/" rel="">![Book of Abstracts](https://bookdown.org/nowosad/Geostatystyka/Rfigs/book_cover2.png)</a>
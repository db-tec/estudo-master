# unison
UNISoN is a Java-based NNTP client that can analyse messages to save to a Pajek-format file for Social Network Analysis. Developed as part of an MSc Business Systems Analysis &amp; Design at City University. 


[![Download unison](https://a.fsdn.com/con/app/sf-download-button)](https://sourceforge.net/projects/unison-sna/files/latest/download)

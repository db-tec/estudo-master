#!/bin/bash

java  -jar unison.jar 
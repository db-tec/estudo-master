package uk.co.sleonard.unison;

/**
 * The Enum MatrixType.
 */
public enum MatrixType {

	/** The reply to all. */
	REPLY_TO_ALL, /** The reply to first. */
	REPLY_TO_FIRST, /** The reply to last. */
	REPLY_TO_LAST
}
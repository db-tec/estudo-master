import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from nxviz import MatrixPlot, ArcPlot, CircosPlot
from hiveplot import HivePlot

# https://thegyre.io/notes/network_analysis/overview/

def load_patent_network():

    # Le lista de arestas
    df_arestas = pd.read_csv('../../cit_patents_list_edges.csv', 
        skiprows=1, header=None, sep=',')
    df_arestas = df_arestas[[0, 1, 3]]
    df_arestas.columns = ['Source', 'Target', 'Weight']

    # Construindo o grafo
    G = nx.DiGraph()
    for row in df_arestas.iterrows():
        n1 = row[1]['Source']
        n2 = row[1]['Target']
        G.add_edge(n1, n2, weight=row[1]['Weight'])

    return G

# Define find_node_with_highest_bet_cent()
def find_node_with_highest_bet_cent(G):

    # Compute betweenness centrality: bet_cent
    bet_cent = nx.betweenness_centrality(G)

    # Compute maximum betweenness centrality: max_bc
    max_bc = max(list(bet_cent.values()))

    nodes = set()

    # Iterate over the betweenness centrality dictionary
    for k, v in bet_cent.items():

        # Check if the current value has the maximum betweenness centrality
        if v == max_bc:

            # Add the current node to the set of nodes
            nodes.add(k)

    return nodes

# Define find_nodes_with_highest_deg_cent()
def find_nodes_with_highest_deg_cent(G):

    # Compute the degree centrality of G: deg_cent
    deg_cent = nx.degree_centrality(G)
    # Compute the maximum degree centrality: max_dc
    max_dc = max(list(deg_cent.values()))

    nodes = set()
    # Iterate over the degree centrality dictionary
    for k, v in deg_cent.items():

        # Check if the current value has the maximum degree centrality
        if v == max_dc:
            # Add the current node to the set of nodes
            nodes.add(k)

    return nodes

G = load_patent_network()

# Imprimir informações básicas do gráfo
print(len(G.nodes()))
print(len(G.edges()))

# Degree Centrality
degree_centrality = nx.degree_centrality(G)
#print(degree_centrality)
print(list(degree_centrality.keys())[0:5])
print(list(degree_centrality.values())[0:5])

# Find the node(s) that has the highest degree centrality in G: top_dc
top_dc = find_nodes_with_highest_deg_cent(G)
print(top_dc)
for n in top_dc:
    print(n)

print()

# Use that function to find the node(s) that has the highest betweenness centrality in the network: top_bc
top_bc = find_node_with_highest_bet_cent(G)
print(top_bc)
for n in top_bc:
    print(n)

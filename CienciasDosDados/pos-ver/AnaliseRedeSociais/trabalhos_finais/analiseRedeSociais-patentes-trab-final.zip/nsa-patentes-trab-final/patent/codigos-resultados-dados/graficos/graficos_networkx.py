import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from nxviz import MatrixPlot, ArcPlot, CircosPlot
from hiveplot import HivePlot

def load_patent_network():

    # Le lista de arestas
    df_arestas = pd.read_csv('../cit_patents_list_edges.csv', 
        skiprows=1, header=None, sep=',')
    df_arestas = df_arestas[[0, 1, 3]]
    df_arestas.columns = ['Source', 'Target', 'Weight']

    # Construindo o grafo
    G = nx.DiGraph()
    for row in df_arestas.iterrows():
        n1 = row[1]['Source']
        n2 = row[1]['Target']
        if not G.has_node(n1):
            G.add_node(n1, type='Source')
        if not G.has_node(n2):
            G.add_node(n2, type='Target')
        G.add_edge(n1, n2, weight=row[1]['Weight'])

    return G

G = load_patent_network()

# Subgrafo a partir dos edges com 'weight' == 6 (apenas as patentes que são do mesmo adquirente)
Gtemp = nx.DiGraph()
[Gtemp.add_edge(u, v, weight=6) for u, v, d in G.edges(data=True) if d['weight'] == 6]
GMesmoAdquirente = G.edge_subgraph(Gtemp.edges()).copy()

# Imprimir informações básicas do gráfo
#print(len(G.nodes()))
#print(len(G.edges()))
print(len(GMesmoAdquirente.nodes()))
print(len(GMesmoAdquirente.edges()))

# Mostra grafo
'''
#nx.draw(G, with_labels=True)
#nx.draw(GMesmoAdquirente, with_labels=True)
nx.draw(GMesmoAdquirente)
plt.show()
'''

# Matriz de adjacencia
'''
#m = MatrixPlot(G)
m = MatrixPlot(GMesmoAdquirente)
m.draw()
plt.show()
#plt.savefig('matriz_adjacencia.png', dpi=600)
#matriz = nx.to_numpy_matrix(G)
'''

# Arcplot
'''
#a = ArcPlot(G, node_color='type', node_grouping='type')
a = ArcPlot(GMesmoAdquirente, node_color='type', node_grouping='type')
a.draw()
plt.show()
'''

# CircosPlot
'''
#c = CircosPlot(G, node_color='type', node_grouping='type')
c = CircosPlot(GMesmoAdquirente, node_color='type', node_grouping='type')
c.draw()
#plt.savefig('source_circosPlot.png', dpi=600)
plt.show()
'''

# Hive Plot
nodes = dict()
#nodes['Source'] = [n for n,d in G.nodes(data=True) if d['type'] == 'Source']
#nodes['Target'] = [n for n,d in G.nodes(data=True) if d['type'] == 'Target']
nodes['Source'] = [n for n,d in GMesmoAdquirente.nodes(data=True) if d['type'] == 'Source']
nodes['Target'] = [n for n,d in GMesmoAdquirente.nodes(data=True) if d['type'] == 'Target']
edges = dict()
#edges['group1'] = G.edges(data=True)
edges['group1'] = GMesmoAdquirente.edges(data=True)
nodes_cmap = dict()
nodes_cmap['Source'] = 'blue'
nodes_cmap['Target'] = 'red'
edges_cmap = dict()
edges_cmap['group1'] = 'black'
h = HivePlot(nodes, edges, nodes_cmap, edges_cmap)
h.draw()
#plt.show()

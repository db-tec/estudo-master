import pandas as pd

df_original = pd.read_csv('../apat63_99.csv', 
	usecols=[
		'GYEAR',
		'COUNTRY',
		'CAT',
		'SUBCAT',
		'PATENT', 
		'ASSCODE', 
		'ASSIGNEE', 
		'NCLASS', 
		'CLAIMS', 
		'CMADE', 
		'CRECEIVE'])[
			['GYEAR', 'COUNTRY', 'CAT', 'SUBCAT', 
			'PATENT', 'ASSCODE', 'ASSIGNEE', 'NCLASS', 
			'CLAIMS', 'CMADE', 'CRECEIVE']]

'''
***********************
** EFETUAR FILTRAGEM **
***********************
["GYEAR" in (1975 ate 1989)]
AND
["COUNTRY" == "US"]
AND 
["NCLASS" in (345, 382, 395, 700, 704, 706, 707, 708, 711, 712, 713, 901)]:
	Class	Title
	345	Computer Graphics Processing, Operator Interface Processing, and Selective Visual Display Systems
	382	Image Analysis
	395	Information Processing System Organization
	700	Data Processing:  Generic Control Systems or Specific Applications
	704	Data Processing: Speech Signal Processing, Linguistics, Language Translation, and Audio Compression/Decompression
	706	Data Processing: Artificial Intelligence
	707	Data Processing:  Database and File Management, Data Structures, or Document Processing
	708	Electrical Computers:  Arithmetic Processing and Calculating
	711	Electrical Computers and Digital Processing Systems: Memory
	712	Electrical Computers and Digital Processing Systems:  Processing Architectures and Instruction Processing (e.g., Processors)
	713	Electrical Computers and Digital Processing Systems:  Support
	901	Robots
AND 
["CAT" == 2] AND ["SUBCAT" == 22]:
	2	22 "Computer Hardware & Software"	"Computers & Communications"
'''
lista_years = list(range(1975,1989))
lista_nclass = [345, 382, 395, 700, 704, 706, 707, 708, 711, 712, 713, 901]
df_list_nodes = df_original[
	(df_original['GYEAR'].isin(lista_years)) & 
	(df_original['COUNTRY'] == 'US') & 
	(df_original['NCLASS'].isin(list(lista_nclass))) & 
	(df_original['CAT'] == 2) & 
	(df_original['SUBCAT'] == 22)]

# Resultado da filtragem acima:
#Nós -> 4172
#Arestas -> 8216

'''
****************************************
** MAPEAR IDENTIFICADORES DE COLUNAS  **
** (Para o formato CSV input de Nodes **
**	para o Gephi)					  **
****************************************
PATENT -> Id
ASSCODE -> Label
ASSIGNEE -> ASSIGNEE
NCLASS -> NCLASS
CLAIMS -> CLAIMS
CMADE -> CMADE
CRECEIVE -> CRECEIVE

Obs.: Significados:
	patent "Patent Number"
	asscode	"Assignee Type"
		1    = unassigned
		2    = assigned to a U.S. nongovernment organization
		3    = assigned to a non-U.S., nongovernment organization
		4    = assigned to a U.S. individual
		5    = assigned to a non-U.S. individual
		6    = assigned to the U.S. (Federal) Government
		7    = assigned to a non-U.S. government
		8,9  = assigned to a U.S. non-Federal Government agency (do not appear in the dataset)
	assignee "Assignee Identifier"
	nclass "Main Patent Class"
	claims	"number of Claims"
	cmade "Number of Citations Made"
	creceive "Number of Citations Received"
'''
df_list_nodes.columns = [
	'GYEAR',
	'COUNTRY',
	'CAT',
	'SUBCAT',
	'Id', # Mudou de 'PATENT' para 'Id'
	'Label', # Mudou 'ASSCODE' para 'Label'
	'ASSIGNEE',
	'NCLASS',
	'CLAIMS',
	'CMADE',
	'CRECEIVE']

# Substituir valores nulos e transformar valores para Inteiro
df_list_nodes = df_list_nodes.fillna(0)
df_list_nodes['ASSIGNEE'] = df_list_nodes['ASSIGNEE'].astype(int)
df_list_nodes['CLAIMS'] = df_list_nodes['CLAIMS'].astype(int)
df_list_nodes['CMADE'] = df_list_nodes['CMADE'].astype(int)

# Salva CSV com lista de nodes apenas com colunas necessárias
# Remove 'GYEAR', 'COUNTRY', 'CAT' e 'SUBCAT'
df_list_nodes.to_csv(
	'apat63_99_patents_list_nodes.csv', 
	columns=[
		'Id', 'Label', 
		'ASSIGNEE', 'NCLASS', 'CLAIMS', 'CMADE', 'CRECEIVE'], 
	encoding='utf-8', index=False, sep=',')

# Ler apenas com as colunas necessárias
df_list_nodes = pd.read_csv('apat63_99_patents_list_nodes.csv')

#print(df_list_nodes.shape)

# Obtem toda a lista de com os PATENT (códigos de patentes)
lista_patents = list(df_list_nodes['Id'])

df_cite75_99_patents = pd.read_csv('../cite75_99.csv')

# Fazendo equivalencia entre os dataframes
df_cit_patents_list_edges = df_cite75_99_patents[
	df_cite75_99_patents['CITING'].isin(lista_patents)]
df_cit_patents_list_edges = df_cit_patents_list_edges[
	df_cit_patents_list_edges['CITED'].isin(lista_patents)]

# Fazendo grafo direcionado
df_cit_patents_list_edges.insert(2, 'Type', 'directed')

# Para calculo dos pesos das arestas:
df_cit_patents_list_edges.insert(3, 'Source_ASSIGNEE', '1')
df_cit_patents_list_edges.insert(4, 'Target_ASSIGNEE', '1')
df_cit_patents_list_edges.insert(5, 'Weight', '1')

# Mudando o header para (Source,Target,Type,Weight)
df_cit_patents_list_edges.columns = ['Source', 'Target', 'Type', 'Source_ASSIGNEE', 'Target_ASSIGNEE', 'Weight']

# Calculo dos pesos (mesmo ASSIGNEE maior peso, diferente ASSIGNEE menor peso)
dic = dict(zip(list(df_list_nodes['Id']), list(df_list_nodes['ASSIGNEE'])))
df_cit_patents_list_edges['Source_ASSIGNEE'] = df_cit_patents_list_edges['Source'].map(dic)
df_cit_patents_list_edges['Target_ASSIGNEE'] = df_cit_patents_list_edges['Target'].map(dic)
for i, row in df_cit_patents_list_edges.iterrows():
	if row['Source_ASSIGNEE'] == row['Target_ASSIGNEE']:
		df_cit_patents_list_edges.at[i, 'Weight'] = 6
	else:
		df_cit_patents_list_edges.at[i, 'Weight'] = 3

df_cit_patents_list_edges.to_csv(
	'cit_patents_list_edges.csv',
	#
	columns=['Source', 'Target', 'Type', 'Weight'],  
	encoding='utf-8', index=False, sep=',')

#df_cit_patents_list_edges = pd.read_csv('cit_patents_list_edges.csv')
#print(df_cit_patents_list_edges.shape)

"""linkpred, a Python module for link prediction"""
from .linkpred import *

__version__ = '0.2'

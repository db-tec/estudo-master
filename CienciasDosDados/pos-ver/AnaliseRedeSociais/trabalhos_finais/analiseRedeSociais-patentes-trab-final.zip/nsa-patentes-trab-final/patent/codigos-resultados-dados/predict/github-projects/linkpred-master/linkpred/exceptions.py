"""Package-specific exceptions"""


class LinkPredError(Exception):
    """Link prediction error"""


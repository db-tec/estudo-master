#!/bin/bash
# POSIX

if [ "x$JAVA_OPTS" = "x" ]; then
   JAVA_OPTS="-Duser.timezone=America/Sao_Paulo"
   #JAVA_OPTS="$JAVA_OPTS -Xms1303m -Xmx1303m -XX:MaxPermSize=768"   
else
   echo "JAVA_OPTS already set in environment"
fi

# Reset all variables that might be set
CONFIG_PATH=/home/03627749430/teste
LOG_PATH=
JAR=cnir-batch-1.0.0-SNAPSHOT-executable.jar
XML=jobs/cnirCSV-job.xml
ID=cnirJob
# D=Desenvolvimento, T=Testes
ENV=T
# N=Normal, R=Reprocessamento
PROC_TYPE=N
# FX1-1=Faixa1-Trecho1, FX1-2=Faixa1-Trecho2, FX2-1=Faixa2-Trecho1, ....
PROC_RANGE=FX

DATE=`date +%Y-%m-%d-%H%M`

#TODO REMOVER
# copia o arquivo executavel da pasta target para a pasta de execucao
if [ -f /home/03627749430/desenv/cnir/workspace/spring-batch/cnir-batch/target/$JAR ]; then
  cp /home/03627749430/desenv/cnir/workspace/spring-batch/cnir-batch/target/$JAR $CONFIG_PATH/$JAR
fi

rm -f $CONFIG_PATH/log/$ID.log


echo "INFRA-BATCH script v1.0"
echo "executando..."
echo "java $JAVA_OPTS -Dinfra.config.dir=$CONFIG_PATH -Dinfra.log.dir=$LOG_PATH -jar $CONFIG_PATH/$JAR $XML $ID incremental=N"

java $JAVA_OPTS -Dinfra.config.dir=$CONFIG_PATH -Dinfra.log.dir=$LOG_PATH -jar $CONFIG_PATH/$JAR $XML $ID incremental=N


# copia o arquivo de log para a pasta de backup de execucao do job
BKP_EXEC_DIR=$CONFIG_PATH/cnirlog/$DATE-$ENV-$PROC_TYPE-$PROC_RANGE
mkdir -p $BKP_EXEC_DIR
mv $CONFIG_PATH/log/$ID.log $BKP_EXEC_DIR/$ID.log


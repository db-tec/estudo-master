#!/bin/bash
# POSIX

INFRA_BATCH_SCRIPT_VERSION="1.0"

if [ "x$JAVA_OPTS" = "x" ]; then
   JAVA_OPTS="-Duser.timezone=America/Sao_Paulo"
   #JAVA_OPTS="$JAVA_OPTS -Xms1303m -Xmx1303m -XX:MaxPermSize=768"   
else
   echo "JAVA_OPTS already set in environment"
fi


 -jar  -x  -i 
# Reset all variables that might be set
CONFIG_PATH=/home/03426710498/teste
LOG_PATH=
JAR=cnir-batch-1.0.0-SNAPSHOT-executable.jar
XML=jobs/cnirCSV-job.xml
ID=cnirJob

echo "INFRA-BATCH script v$INFRA_BATCH_SCRIPT_VERSION"
echo "executando..."
echo "java $JAVA_OPTS -Dinfra.config.dir=$CONFIG_PATH -Dinfra.log.dir=$LOG_PATH -jar $CONFIG_PATH/$JAR $XML $ID"

java $JAVA_OPTS -Dinfra.config.dir=$CONFIG_PATH -Dinfra.log.dir=$LOG_PATH -jar $CONFIG_PATH/$JAR $XML $ID


/**
 * Package showing projection features.
 */
package example.springdata.cassandra.projection;
